BeebEm for Microsoft Windows
============================

BeebEm is a BBC Micro and Master 128 emulator.  It enables you to run BBC
Micro software on your PC.  BeebEm should work on most PC systems running
Windows XP or later.

The copyright for BeebEm is held by David Alan Gilbert and the other authors
and contributors.  BeebEm is distributed under the terms of the GNU General
Public License, as described in COPYRIGHT.txt.

For more information see the BeebEm help:

  Help\index.html

The source code for BeebEm is available at:

  https://github.com/stardot/beebem-windows

Mike Wyatt
beebem.support@googlemail.com
http://www.mkw.me.uk/beebem

Copyright (C) 2018  Mike Wyatt
